package com.udacity.project4.locationreminders.data.local

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider.getApplicationContext
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.SmallTest;
import com.udacity.project4.locationreminders.data.dto.ReminderDTO

import org.junit.Before;
import org.junit.Rule;
import org.junit.runner.RunWith;

import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.*
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Test

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
//Unit test the DAO
@SmallTest
class RemindersDaoTest {

//    TODO: Add testing implementation to the RemindersDao.kt
   @get:Rule
   var instantExcuteRule =InstantTaskExecutorRule()
    private val remind1 = ReminderDTO("1", "first", "loc", 122.6, 122.7)
    private  val remind2 = ReminderDTO("2", "second", "loc2", 0.0, 0.0)
    private lateinit var data: RemindersDatabase


@Before
fun init_dataBase(){
    data=Room.inMemoryDatabaseBuilder(getApplicationContext(),RemindersDatabase::class.java).allowMainThreadQueries().build()
}
    @After
    fun close_DataBase(){data.close()}

    @Test
    fun insert_Reminders_And_FetchAll()= runBlockingTest {
        data.reminderDao().saveReminder(remind1)
        data.reminderDao().saveReminder(remind2)
        val load=data.reminderDao().getReminders()
        assertThat(load.isNotEmpty(), `is`(true))
    }
    @Test
    fun insert_FindbyId()=
runBlockingTest {
data.reminderDao() .saveReminder(remind1)
    val check= data.reminderDao().getReminderById(remind1.id)
    assertThat(check as ReminderDTO, notNullValue())
    assertThat(check.id, `is`(remind1.id))
    assertThat(check.description, `is`(remind1.description))
    assertThat(check.title, `is`(remind1.title))
    assertThat(check.longitude,`is`(remind1.longitude))
    assertThat(check.latitude, `is`(remind1.latitude))
    assertThat(check.location, `is`(remind1.location))
}


    @Test
    fun insert_andDelete()= runBlockingTest {
        //Inserting  and deleting
        data.reminderDao().saveReminder(remind1)
        data.reminderDao().deleteAllReminders()
        assertThat(data.reminderDao().getReminderById(remind1.id), `is`(nullValue()))
    }
    @Test
    fun deleteAll()= runBlockingTest{
        //Inserting and delete all
        data.reminderDao().saveReminder(remind1)
data.reminderDao().deleteAllReminders()
        assertThat(data.reminderDao().getReminders().isEmpty(), `is`(true))
    }



}
