package com.udacity.project4.locationreminders.reminderslist

import android.os.Bundle
import androidx.fragment.app.testing.launchFragmentInContainer
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import com.udacity.project4.R
import com.udacity.project4.locationreminders.data.ReminderDataSource
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.data.local.LocalDB
import com.udacity.project4.locationreminders.data.local.RemindersLocalRepository
import com.udacity.project4.locationreminders.savereminder.SaveReminderViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin
import org.koin.dsl.module
import org.mockito.Mockito.mock
import org.mockito.Mockito.verify
import org.koin.test.get
import org.koin.test.AutoCloseKoinTest


@RunWith(AndroidJUnit4::class)
@ExperimentalCoroutinesApi
//UI Testing
@MediumTest
class ReminderListFragmentTest :AutoCloseKoinTest(){
    //VARIABLES
private lateinit var dataSource: ReminderDataSource
    private val navController= mock(NavController::class.java)
private lateinit var viewModel: RemindersListViewModel


@Before
fun initalize(){
stopKoin()
    val module= module {
viewModel {
    RemindersListViewModel (ApplicationProvider.getApplicationContext(),get() as ReminderDataSource)}
        single {
            SaveReminderViewModel(ApplicationProvider.getApplicationContext(),get() as ReminderDataSource)
        }
single { RemindersLocalRepository(get()) as ReminderDataSource }
    single {
        LocalDB.createRemindersDao(ApplicationProvider.getApplicationContext()) }
    }
startKoin {
modules(listOf(module))
}
    dataSource=get()
runBlocking {
dataSource.deleteAllReminders()
}
viewModel=RemindersListViewModel(ApplicationProvider.getApplicationContext(),dataSource)
}
//    TODO: test the displayed data on the UI.
@Test
fun dataDisplayed(){
launchFragmentInContainer<ReminderListFragment>(Bundle(), R.style.AppTheme)
onView(withText("No Data")).check(matches(isDisplayed()))
}
//    TODO: add testing for the error messages.
@Test
fun navigateOnclick(){
     val sec= launchFragmentInContainer<ReminderListFragment>(Bundle(),R.style.AppTheme)
         sec.onFragment { Navigation.setViewNavController(it.view!!,navController) }
    onView(withId(R.id.addReminderFAB)).perform(click())
verify(navController).navigate(ReminderListFragmentDirections.toSaveReminder())

}
@Test
fun reminderDisplayed(){
    //Test Reminders
val remind=ReminderDTO("1","2","3",111.1,120.9)
    runBlocking {
        dataSource.saveReminder(remind)
    }
    launchFragmentInContainer<ReminderListFragment>(Bundle(),R.style.AppTheme)
    onView(withText(remind.location)).check(matches(isDisplayed()))
    onView(withText(remind.title)).check(matches(isDisplayed()))
    onView(withText(remind.description)).check(matches(isDisplayed()))
}
}