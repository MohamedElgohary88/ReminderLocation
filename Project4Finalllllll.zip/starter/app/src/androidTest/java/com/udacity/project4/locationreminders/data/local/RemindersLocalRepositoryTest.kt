package com.udacity.project4.locationreminders.data.local

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.data.dto.Result
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.TestCoroutineDispatcher
import org.hamcrest.CoreMatchers
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
//Medium Test to test the repository
@MediumTest
class RemindersLocalRepositoryTest {
    //VARIABLES
  private  val remind1=ReminderDTO("1","2","3",100.0,120.0)
   private val remind2 = ReminderDTO("2", "second", "loc2", 0.0, 0.0)
    private lateinit var data: RemindersDatabase
    private lateinit var repository:RemindersLocalRepository
    @Before
    fun init_dataBase(){
        data=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),RemindersDatabase::class.java).allowMainThreadQueries().build()
        repository=RemindersLocalRepository(data.reminderDao(),TestCoroutineDispatcher())
    }
    @After
    fun close_DataBase(){data.close()}
    @Test
    fun inserting_FindById()= runBlocking {
    repository.saveReminder(remind1)
    val result=repository.getReminder(remind1.id) as Result.Success<ReminderDTO>
        val loaded=result.data
        assertThat(loaded as ReminderDTO, CoreMatchers.notNullValue())
        assertThat(loaded.id, `is`(remind1.id))
        assertThat(loaded.description, `is`(remind1.description))
        assertThat(loaded.title, `is`(remind1.title))
        assertThat(loaded.longitude, `is`(remind1.longitude))
        assertThat(loaded.latitude, `is`(remind1.latitude))
        assertThat(loaded.location, `is`(remind1.location))
    }
    @Test
    fun getRemindes_orNull()= runBlocking{
        data.reminderDao().saveReminder(remind2)
        data.reminderDao().saveReminder(remind1)
        val result :Result<List<ReminderDTO>> = repository.getReminders()
        assertThat(result is Result.Success, `is`(true))
        if (result !is Result.Success) {
        } else assertThat(result.data.isNotEmpty(),`is`(true))

    }
    //REMINDER NOT FOUND DONE
    @Test
    fun reminderNotFound() = runBlocking {
        val result = repository.getReminder(remind1.id)
        assertThat(result is Result.Error, `is`(true))

        result as Result.Error

        assertThat(result.message,`is`("Reminder not found!"))

    }
    @Test
    fun deleteAllRemindes()= runBlocking {
repository.deleteAllReminders()
        val res=repository.getReminders() as com.udacity.project4.locationreminders.data.dto.Result.Success
        val dataRes=res.data
        assertThat(dataRes,`is`(emptyList()))
    }
    @Test
    fun add_delete_SingleReminder()= runBlocking {
        repository.saveReminder(remind1)
        repository.deleteAllReminders()
        //checked the id
        assertThat(repository.getReminder(remind1.id) is Result.Error,`is`(true))

    }

}