package com.udacity.project4.locationreminders.data

import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.data.dto.Result

//Use FakeDataSource that acts as a test double to the LocalDataSource
class FakeDataSource : ReminderDataSource {

private var list= mutableListOf<ReminderDTO>()
private var shouldReturnError:Boolean=false
fun setReturnError(item:Boolean){
shouldReturnError=item
}
    override suspend fun getReminders(): Result<List<ReminderDTO>> {

        if (shouldReturnError) {
            return Result.Error("ERROR")
        } else {
            return Result.Success<List<ReminderDTO>>(list)
        }
    }

    override suspend fun saveReminder(reminder: ReminderDTO) {

list.add(reminder)
    }

    override suspend fun getReminder(id: String): Result<ReminderDTO> =
        if (shouldReturnError) {
            Result.Error("ERROR")
        } else {
            val reminder = list.find { it.id == id }

            if (reminder == null) {
                Result.Error("Not Found")
            } else {
                Result.Success(reminder)
            }
        }


    override suspend fun deleteAllReminders() {
list.removeAll(list)
    }


}