package com.udacity.project4.locationreminders.savereminder

import android.content.Context
import android.os.Build
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PointOfInterest
import com.udacity.project4.MyApp
import com.udacity.project4.R
import com.udacity.project4.base.NavigationCommand
import com.udacity.project4.locationreminders.Main_Couroutine_Rule
import com.udacity.project4.locationreminders.data.FakeDataSource
import com.udacity.project4.locationreminders.data.dto.Result
import com.udacity.project4.locationreminders.getOrAwaitValue
import com.udacity.project4.locationreminders.reminderslist.ReminderDataItem

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.*
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.core.IsInstanceOf
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.core.context.stopKoin
import org.robolectric.annotation.Config

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
@Config(maxSdk = Build.VERSION_CODES.P)
class SaveReminderViewModelTest {
    //VARIABLES
    private lateinit var  dataSource: FakeDataSource
    private   val latlng=LatLng(120.0,150.0)
    private val poi=PointOfInterest(latlng,"placeOne","A special player")
    private  val notFaultReminder=ReminderDataItem("1","2","3",123.0,124.0)
    private lateinit var saveReminderViewModel: SaveReminderViewModel
    private  val reminderT= ReminderDataItem("1","2","3",100.0,100.0)


    @get:Rule
    var instanceExcutabler_Role= InstantTaskExecutorRule()
    private val fault=ReminderDataItem("","","",123.0,125.0)
    @get:Rule
    var main_Coutoutine_Rule= Main_Couroutine_Rule()

@Before
fun set_VIEWMODEL(){
   dataSource=FakeDataSource()
    val app :MyApp =ApplicationProvider.getApplicationContext()
    saveReminderViewModel= SaveReminderViewModel(app,dataSource)
}
    @Before
    fun tearVIEWMODEL(){
stopKoin()
    }
    @Test
    fun confoirm_Location(){
saveReminderViewModel.confirmLoc(latlng,poi)
        assertThat(saveReminderViewModel.longitude.value,`is`(latlng.longitude))
        assertThat(saveReminderViewModel.latitude.value,`is`(latlng.latitude))
        assertThat(saveReminderViewModel.selectedPOI.value,`is`(poi))
        assertThat(saveReminderViewModel.navigationCommand.value,IsInstanceOf(NavigationCommand.Back::class.java))
        assertThat(saveReminderViewModel.reminderSelectedLocationStr.value,`is`(poi.name))
        saveReminderViewModel.onClear()
    }
    @Test
    fun validateSaveReminders()= runBlockingTest{
        dataSource.deleteAllReminders()
        saveReminderViewModel.validateAndSaveReminder(notFaultReminder)
        saveReminderViewModel.validateAndSaveReminder(fault)
            val error1=dataSource.getReminder(fault.id) as Result.Error
        assertThat(error1.statusCode, `is`(nullValue()))
        assertThat(dataSource.getReminder(notFaultReminder.id),`is`(notNullValue()))

    }

    @Test
    fun validateReminder()= runBlockingTest{
        assertThat(saveReminderViewModel.validateEnteredData(notFaultReminder),`is`(true))
        assertThat(saveReminderViewModel.validateEnteredData(fault),`is`(false))

    }
    //testing of toast
    @Test
    fun saveReminder_ShowToast()=  runBlockingTest{
        saveReminderViewModel.saveReminder(reminderT)
        val value= saveReminderViewModel.showToast.getOrAwaitValue()
        assertThat(value,`is`(ApplicationProvider.getApplicationContext<Context>().getString(R.string.reminder_saved)))
    }
}