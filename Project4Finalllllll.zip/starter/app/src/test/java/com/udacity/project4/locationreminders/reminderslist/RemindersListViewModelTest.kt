package com.udacity.project4.locationreminders.reminderslist

import android.os.Build
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.udacity.project4.locationreminders.Main_Couroutine_Rule
import com.udacity.project4.locationreminders.data.FakeDataSource
import com.udacity.project4.locationreminders.getOrAwaitValue
import junit.framework.TestCase.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.*
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.core.context.stopKoin
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@ExperimentalCoroutinesApi
@Config(maxSdk = Build.VERSION_CODES.P)

class RemindersListViewModelTest {
    @get:Rule
var instanceexcutablerRole=InstantTaskExecutorRule()
    @ExperimentalCoroutinesApi
    @get:Rule
var mainCoutoutineRule= Main_Couroutine_Rule()
    private lateinit var fakeDataSource: FakeDataSource
    private lateinit var remindersListViewModel:RemindersListViewModel
@Before
fun setup_VIEWMODEL(){
    stopKoin()
    fakeDataSource= FakeDataSource()
remindersListViewModel= RemindersListViewModel(ApplicationProvider.getApplicationContext(),fakeDataSource)
}
@After
fun shutDown_VIEWMODEL(){
stopKoin()
}
    //TODO: provide testing to the RemindersListViewModel and its live data objects
    //Checking Coroutine
@Test
fun checkLoading()=mainCoutoutineRule.runBlockingTest{
mainCoutoutineRule.pauseDispatcher()
remindersListViewModel.loadReminders()
        //before start showloading is true
assertTrue(remindersListViewModel.showLoading.getOrAwaitValue())
        mainCoutoutineRule.resumeDispatcher()
        //after , showloading is false
        assertFalse(remindersListViewModel.showLoading.getOrAwaitValue())
}
    //Checking the Live Data
    @Test
    fun checkError(){
fakeDataSource.setReturnError(true)
remindersListViewModel.loadReminders()
assertEquals("ERROR",remindersListViewModel.showSnackBar.getOrAwaitValue())
    }
    @Test
    fun remindersEmpty()=runBlockingTest{
fakeDataSource.deleteAllReminders()
        remindersListViewModel.loadReminders()
        assertThat(remindersListViewModel.showNoData.value,`is`(true))
    }
    @Test
    fun shouldRetuernEmpty()= mainCoutoutineRule.runBlockingTest{
        fakeDataSource.deleteAllReminders()
        remindersListViewModel.loadReminders()
        val res=remindersListViewModel.showSnackBar.value
        assertThat(res,`is`(nullValue()))
        assertThat(remindersListViewModel.showNoData.value,`is`(true))
    }


}