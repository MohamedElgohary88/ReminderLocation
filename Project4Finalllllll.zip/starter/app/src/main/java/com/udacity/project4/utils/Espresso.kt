package com.udacity.project4.utils

import androidx.test.espresso.idling.CountingIdlingResource

object Espresso{
private const val resourse="GLOBAL"
@JvmField
val counting_id_resource=CountingIdlingResource(resourse)
fun decrement(){
if(counting_id_resource != null){
counting_id_resource.decrement()
}
}
    fun incresment_not_empty(){
counting_id_resource.increment()
    }

}

inline fun<T> wrapEspressoIdilngResoucere(function: () -> T):T{
Espresso.incresment_not_empty()
    return try{
function()
    }
    finally {
Espresso.decrement()
    }
}