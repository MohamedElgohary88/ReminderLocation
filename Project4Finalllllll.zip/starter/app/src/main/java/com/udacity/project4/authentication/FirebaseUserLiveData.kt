package com.udacity.project4.authentication

import androidx.lifecycle.LiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class FirebaseUserLiveData : LiveData<FirebaseUser>() {
    private val firebase_auth= FirebaseAuth.getInstance()
    private val stateListner=FirebaseAuth.AuthStateListener { firebaseAuth ->
        value=firebaseAuth.currentUser
    }
    override fun onActive() {
        firebase_auth.addAuthStateListener (stateListner)
    }

    override fun onInactive() {
        firebase_auth.removeAuthStateListener (stateListner )
    }

}