package com.udacity.project4.locationreminders.savereminder.selectreminderlocation


import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.*
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.android.material.snackbar.Snackbar
import com.udacity.project4.BuildConfig
import com.udacity.project4.R
import com.udacity.project4.base.BaseFragment
import android.location.Geocoder
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.findNavController
import com.udacity.project4.databinding.FragmentSelectLocationBinding
import com.udacity.project4.locationreminders.savereminder.SaveReminderViewModel
import com.udacity.project4.utils.setDisplayHomeAsUpEnabled
import org.koin.android.ext.android.inject
import java.util.*

class SelectLocationFragment : BaseFragment() , OnMapReadyCallback{

    //Use Koin to get the view model of the SaveReminder

    //VARIABLES
    override val _viewModel: SaveReminderViewModel by inject()
    private lateinit var fusedLlocationpro: FusedLocationProviderClient
    private lateinit var binding: FragmentSelectLocationBinding
    private lateinit var map: GoogleMap
    private val REQUEST_LOCATION_PERMISSION = 1001
    private var selected_poi: Marker? = null
    private var current_poi:PointOfInterest?=null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_select_location, container, false)

        binding.viewModel = _viewModel
        binding.lifecycleOwner = this
        setHasOptionsMenu(true)
        setDisplayHomeAsUpEnabled(true)

        fusedLlocationpro = LocationServices.getFusedLocationProviderClient(this.requireContext())

        val mapFrag = childFragmentManager.findFragmentById(R.id.map1) as SupportMapFragment
        mapFrag.getMapAsync(this)
        binding.savelocation.setOnClickListener {LocationSelected() }

        return binding.root
    }

    override fun onStart() {
        super.onStart()
        _viewModel.locIsCon.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            if (it) {
                LocationSelected()
            }
        })
    }

    //PERMISSION METHODS
    private fun is_PermissionGranted() :Boolean{
        return ContextCompat.checkSelfPermission(requireContext(),Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
                &&ContextCompat.checkSelfPermission(requireContext(),Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
    }
    private fun isForegroundPermissionEnalbed(): Boolean {
        return (PackageManager.PERMISSION_GRANTED ==
                ContextCompat.checkSelfPermission(
                    requireActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION
                ))
    }
    private fun request_ForegroundPermission() {
        val permission_array = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        requestPermissions(permission_array, REQUEST_LOCATION_PERMISSION)
    }
    @SuppressLint("MissingPermission")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (isForegroundPermissionEnalbed()) {
            enableLocation()
        } else {
            when {
                shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION) -> {
                    Snackbar.make(
                        requireView(),
                        getString(R.string.per1),
                        Snackbar.LENGTH_SHORT
                    ).setAction(
                        getString(
                            R.string.enable1
                        )
                    ) {
                        request_ForegroundPermission()
                    }.show()
                }
                else -> {
                    Snackbar.make(requireView(), "location denied", Snackbar.LENGTH_SHORT)
                        .setAction("change Permission") {
                            startActivity(Intent().apply {
                                data =
                                    Uri.fromParts("package", BuildConfig.APPLICATION_ID, null)

                                action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS

                                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                            })
                        }.show()
                }
            }
        }
    }

    //LOCATION METHODS
    private fun LocationSelected() {
        if (current_poi != null) {
            _viewModel.savePoi(current_poi)
            findNavController().navigate(SelectLocationFragmentDirections.actionSelectLocationFragmentToSaveReminderFragment())
        } else {
            Toast.makeText(context,"Please select a locaation",Toast.LENGTH_LONG).show()
        }
    }
    @SuppressLint("MissingPermission")
    private fun enableLocation() {
        if (is_PermissionGranted()) {
            map.isMyLocationEnabled=true
            zoom_toCurrentLocation(true)
        } else {
            if(shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)){
                _viewModel.showSnackBar.postValue(getString(R.string.permission_denied_explanation))
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),REQUEST_LOCATION_PERMISSION)
            } else{
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),REQUEST_LOCATION_PERMISSION)
            }
        }

    }
    @SuppressLint("MissingPermission")
    private fun zoom_toCurrentLocation(f:Boolean) {
        val request_Location=LocationRequest.create().apply { priority=LocationRequest.PRIORITY_LOW_POWER }
        val builder=LocationSettingsRequest.Builder().addLocationRequest(request_Location)
        val client=LocationServices.getSettingsClient(requireActivity())
        val response=client.checkLocationSettings(builder.build())
        response.addOnFailureListener{
            if (it !is ResolvableApiException || !f) {
                Snackbar.make(binding.root,"Must Enable Location services",Snackbar.LENGTH_INDEFINITE).setAction("Ok"){zoom_toCurrentLocation(true)}.show()
            } else {
                startIntentSenderForResult(it.resolution.intentSender,
                    1002,null,
                    0,0,0,null)
            }
        }
        response.addOnCompleteListener {
            if (!it.isSuccessful) {
            } else {
                fusedLlocationpro.lastLocation.addOnSuccessListener { loc: Location? ->
                    if (loc!=null){
                        val zoom=15f
                        val home=LatLng(loc.latitude,loc.longitude)
                        map.moveCamera(CameraUpdateFactory.newLatLngZoom(home,zoom))
                    }
                }
            }
        }
    }

//MAP METHODS

    @RequiresApi(Build.VERSION_CODES.Q)
        override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        set_POI(map)
        map.setMapStyle(MapStyleOptions.loadRawResourceStyle(requireActivity(), R.raw.map_style))
        MapListner(map)
        enableLocation()
    }
    private fun MapListner(map:GoogleMap){
        map.setOnMapClickListener {
            val address=Geocoder(context,Locale.getDefault()).getFromLocation(it.latitude,it.longitude,1)
            if(address.isNotEmpty()){
                val address:String=address[0].getAddressLine(0)
                val addressPOI=PointOfInterest(it,null,address)
                selected_poi?.remove()
                val poi_Marker=map.addMarker(MarkerOptions().position(addressPOI.latLng).title(addressPOI.name))
                poi_Marker.showInfoWindow()
                selected_poi=poi_Marker
                current_poi=addressPOI
            }
        }

    }
    private fun set_POI(map:GoogleMap){
        map.setOnPoiClickListener{
            selected_poi?.remove()
            val marker=map.addMarker(MarkerOptions().position(it.latLng).title(it.name))
            marker.showInfoWindow()
            current_poi=it
            selected_poi=marker

        }
    }

    //MENU METHODS
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.map_options, menu)
    }
    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {

        R.id.normal_map -> {
            map.mapType = GoogleMap.MAP_TYPE_NORMAL
            true
        }
        R.id.hybrid_map -> {

            map.mapType = GoogleMap.MAP_TYPE_HYBRID
            true
        }
        R.id.satellite_map -> {
            map.mapType = GoogleMap.MAP_TYPE_SATELLITE
            true
        }
        R.id.terrain_map -> {

            map.mapType = GoogleMap.MAP_TYPE_TERRAIN
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

}

